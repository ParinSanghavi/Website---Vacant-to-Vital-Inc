
# Vacant2Vital - uxteamtwo
Much land in Raleigh is vacant, and will be for the foreseeable future. Vacant To Vital seeks to change this by connect those in need of temporary access to land with those who have unused land.
  We did field research and realised how much productivity empty lands in the area can bring if we can connect it to people who can do  something good about it from agriculture's point of view. 
